package com.example.sprinstarter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprinstarterApplicationTests {

	@Test
	void contextLoads() {
	}

}
