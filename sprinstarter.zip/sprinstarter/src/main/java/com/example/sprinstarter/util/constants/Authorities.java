package com.example.sprinstarter.util.constants;

public enum Authorities {
    
}
