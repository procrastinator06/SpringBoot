package com.example.sprinstarter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprinstarterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprinstarterApplication.class, args);
	}

}
